<?php
echo "[*] Listing Docker Images...\n";
$sock = socket_create(AF_UNIX, SOCK_STREAM, 0);
socket_connect($sock, "/var/run/docker.sock");

$req = "GET /v1.41/images/json HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n";
socket_write($sock, $req);

$res = "";
while ($buf = socket_read($sock, 2048)) { $res .= $buf; }
echo $res;
socket_close($sock);
?>
